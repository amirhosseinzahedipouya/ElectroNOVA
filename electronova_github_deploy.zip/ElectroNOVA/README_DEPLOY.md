# Electro NOVA deployment package

Prepared for deployment on Render via GitHub.

1. Upload this folder contents to a new GitHub repository.
2. On Render, choose New > Blueprint, connect that repository, and accept render.yaml.
3. Set ADMIN_USERNAME, ADMIN_PASSWORD and JWT_SECRET (32+ random characters).
4. Deploy. The service hosts frontend and API, with SQLite and uploaded images on persistent disk.
5. Open the deployed URL; /api/health should return ok:true.

Payments are not integrated. Orders are demo submissions. Review hosting plans and security before publishing.
