# Electro NOVA Full-stack starter

Frontend: HTML/CSS/JavaScript. Backend: Node.js + Express + SQLite. Includes product listing/search, category filtering, related products, popular shelf, cart drawer, demo order submission, protected admin login, CRUD product/category, image upload, orders list, theme toggle and basic UI language switching.

## Run locally
1. Install Node.js 20+.
2. In `backend`, copy `.env.example` to `.env` and set `ADMIN_USERNAME`, `ADMIN_PASSWORD` and a long `JWT_SECRET`.
3. `cd backend && npm install && npm start`
4. Open `frontend/index.html` using a local web server (for example VS Code Live Server), not `file://` if browser CORS restrictions arise. Frontend API URL is currently `http://localhost:4000/api`.

## Important
This is a development starter, not production-ready. Use HTTPS, configure origin-specific CORS, rate limiting, secure deployment secrets, backups, order privacy and audit logging before publishing. Orders are demo submissions; no payment provider is connected. Admin user is created from environment variables only when the database has no matching username. If no credentials are configured, login cannot be created automatically.
